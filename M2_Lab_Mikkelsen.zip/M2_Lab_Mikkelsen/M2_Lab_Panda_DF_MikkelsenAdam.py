#03/26/2024
#Adam Mikkelsen
#CSC-221 M2 Lab - Panda DF

import pandas as pd

def main():
    #send data to a variable - email is the index
    contacts = pd.read_csv("contacts.csv")
    
    #display dataframe
    print(contacts)
    print()
    
    #Use info function
    contacts.info(verbose = True)
    print()
    
    #determine length
    print(len(contacts))
    #Use size method
    print(contacts.size)
    print()
    
    #display first two rows
    print(contacts.head(2))
    print()
    
    #display last two rows
    print(contacts.tail(2))
    print()
    
    #display phone
    print(contacts['phone'])
    print()
    
    #display first and last
    newDF = contacts[['first','last']]
    print(newDF)
    print()
    
    #print a specific phone number
    match = contacts.loc[contacts['email'] == 'smsmith@yahoo.com']
    phone = match['phone']
    print(phone)
    print()
    
    #display dataframe as sorted
    contacts = contacts.sort_values(by=['last','first'])
    print(contacts)
    print()
    
    #display rows where the first namme is dan
    print(contacts[contacts['first'] == 'Dan'])
    print()
    
    #display rows without phone numbers
    missingVal = contacts.loc[contacts['phone'].isnull()]
    print(missingVal)
    print()
    
    #update tess's number
    contacts.loc[contacts['first'] == 'Tess', 'phone'] = '555-1233'
    print(contacts)
    print()
    
    #drop tess's row
    contacts = contacts.drop(contacts[contacts.email == 'tessbijon@gmail.com'].index)
    print(contacts)
    print()
    
    #add new row
    contacts.loc[len(contacts.index)] = ['stefsmith@gmail.com', 'Stef', 'Smith', '801-555-9876']
    print(contacts)
    print()
    
    #join with another csv
    toAdd = pd.read_csv('contact-states.csv')
    contactsPlus = contacts.join(toAdd.set_index('email'), on= 'email')
    print(contactsPlus)
    print()
    
    
    
    

if __name__ == '__main__':
    main()
