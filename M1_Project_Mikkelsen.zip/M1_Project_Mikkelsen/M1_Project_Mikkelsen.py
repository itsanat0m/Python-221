# M1 Project
# Adam Mikkelsen
# 3/19/24

import csv
import functions
from projectClasses import Customer, Premium, Product


def main():
    
    customerList, productList = functions.makeLists()
    orders = []

    userID = input('Please enter your customer ID: ')
    for person in customerList:
        if person.custID == userID:
            user = person
            notUser = False
            break
        else:
            notUser = True
    if notUser == True:
        print('ID not found. You must be a customer to purchace items.')

    order = functions.purchaseItem(user, productList)
    orders.append(order)

    cont = input('Would you like to buy another item? (y/n) ')
    while cont == 'y' or cont == 'Y':
        order = functions.purchaseItem(user, productList)
        orders.append(order)
        cont = input('Would you like to buy another item? (y/n) ')

    total = float(0)

    for item in orders:
        toAdd = item.orderItem.price * item.quantity
        total += toAdd
        
    if isinstance(user, Premium):
        total = total *.9

    print(f'Your total is : ${total}.')
    
    


    

if __name__ == '__main__':
    main()
    
