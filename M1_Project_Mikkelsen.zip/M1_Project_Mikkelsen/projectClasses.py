class Customer:
    def __init__(self, firstName, lastName, custID):
        self.custID = custID
        self.firstName = firstName
        self.lastName = lastName

class Premium(Customer):
    def __init__(self, firstName, lastName, custID):
        super().__init__(firstName, lastName, custID)
        self.custID = custID+ "_100"

class Product:
    def __init__(self, productID, productDes, price):
        self.productID = productID
        self.productDes = productDes
        self.price = price

class Order:
    def __init__(self, orderItem, customer, quantity):
        self.orderItem = orderItem
        self.customer = customer
        self.quantity = quantity
