import csv
from projectClasses import Customer, Premium, Product, Order

def makeLists():
    customerList = []
    productList =[]

    with open('customers.csv', 'r') as file:
        reader = csv.reader(file, delimiter = ',')
        for row in reader:
            if row[0] != 'id':
                if row[3] == 'Y':
                    current = Premium(row[2], row[1], row[0])
                else:
                    current = Customer(row[2], row[1], row[0])
                customerList.append(current)

    with open('products.csv','r') as file:
        reader = csv.reader(file, delimiter = ',')
        for row in reader:
            if row[0] != 'id':
                price = float(row[2][1:])
                current = Product(row[0], row[1], price)
                productList.append(current)

    return customerList, productList

def purchaseItem(user, products):
    print()
    toBuy = input('Enter the ID of it product you wish to purchase: ')
    for item in products:
        if item.productID == toBuy:
            itemBuy = item
            isItem = True
        else:
            isItem = False
    quantity = int(input('How many would you like to buy: '))
    userOrder = Order(itemBuy, user, quantity)
    return userOrder
