#Debugging code for Module 1 lab
#Adam Mikkelsen
#CSC-221

from perrson import Person
import csv



class Employee(Person):
    def __init__(self, lastName, firstName, status, salary):
        Person.__init__(self, lastName, firstName)
        self.__position = ""
        self.__status = status
        self.__salary = salary
        
    
    def set_position(self,position):
        self.__position = position

    def get_position(self):
        return self.__position

    def set_status(self, status):
        self.__status = status
        
    def get_status(self):
        return self.__status

    def set_salary(self, salary):
        self.__salary = salary
        
    def get_salary(self):
        return self.__salary

    def __str__(self):
        return f'{self.get_firstName():<15}{self.get_lastName():<15}{self.get_email():<27}{self.get_position():<15}{self.get_salary():<10}{self.get_status()}'

        




def main():

    choice = ''
    while choice != 'EXIT':

        employee = Employee(lastName = "jack",firstName = "john",status = "full",salary = 0)

        
        
        print("Menu")
        print("----------------")
        print("1. Enter Employee Info and write to .txt and .csv files: " 
              + "\n2. Read Employee Info from .txt and csv files (if existing) " 
              + "\n3. Exit Program")
        choice = str(input("Please enter your choice: "))
        
        
        header = f"First Name     Last Name      Email(Company Email)       Position       Salary    Part/Full\n"
                

        if choice == '1':
            #Write to txt and csv
            with open('employees.txt','w') as outFile:
                outFile.writelines(header)
                
            with open('employees.csv' , 'w', newline='') as outFile:
                writer = csv.writer(outFile)
                writer.writerow(["First Name","Last Name","Email", "Position","Salary", "Part/Full Time"])
                
            
            empNum = int(input("How many employees info would you like to enter? "))
            for i in range(0,empNum):
               
                first = input("First Name: ")
                last = input("Last Name: ")
                position = input("Position: ")
                partFull = input("Part/Full Time: ")
                salary = input("Enter Salary: ")
                print()

                # complete section here. create an instance of Employee then write instance information to a .txt AND a .csv file
                newEmp = Employee(firstName = first,lastName = last,status = partFull,salary = salary)
                newEmp.set_position(position)
                with open('employees.txt','a') as outFile:
                    outFile.writelines(newEmp.__str__() + '\n')
                with open('employees.csv','a',newline = '') as outFile:
                    first = newEmp.get_firstName()
                    last = newEmp.get_lastName()
                    email = newEmp.get_email()
                    position = newEmp.get_position()
                    salary = newEmp.get_salary()
                    status = newEmp.get_status()
                    writer = csv.writer(outFile)
                    writer.writerow([first,last,email,position,salary,status])
       
        elif choice == "2":
            try:
                with open('employees.txt','r') as file:
                    lines = file.readlines()
                    for i in lines:
                        print(i)

                with open('employees.csv','r') as file:
                    reader = csv.reader(file, delimiter = ' ')
                    for row in reader:
                        print(row)

            except:
                print("File Error! Please use option 1!")
              

        elif choice == "3":
            print("Closing program! Good bye.")
            choice = 'EXIT'
           
        else:
            print("This is not a valid option! Please choose from the menu. \n\n")

        

           

if __name__ == "__main__":
    main()






